# JUUL Sentiment Analysis using Machine Learning
# Load packages 
library(stringr)
library(parallel)
library(e1071) # Naive Bayes
library(randomForest)
library(RTextTools) # ML approaches
library(RSQLite)

db <- dbConnect(drv=RSQLite::SQLite(), dbname='juul.db')
tables <- dbListTables(db)
Juul <- dbReadTable(db, 'juul_ml_table')
# This closes the connection, discards all pending work, and frees resources (e.g., memory, sockets).
dbDisconnect(db)

graphics.off()

set.seed(1982)
cvFolds <- 7 # Cross-Validation Folds

Juul$index <- NULL # Remove the index column
colnames(Juul) # Print the column names: Text and Sentiment(Class)

# count the total number of NA values in this dataframe
sum(is.na(Juul))

# remove missing values
Juul <- na.omit(Juul)

# We can also get a glimpse at how tags ar distributed. In R we can use table.
table(Juul$Sentiment)

# Rename the Tweet column
names(Juul)[1] <- "Text"

# How long on average are our sentences in words?
mean(sapply(sapply(Juul$Text, strsplit, " "), length))

# Data Preprocessing
Juul$Text <- iconv(Juul$Text, to = "ASCII", sub = " ")  # Convert to basic ASCII text to avoid silly characters
Juul$Text <- tolower(Juul$Text)  # Make everything consistently lower case
Juul$Text <- gsub("rt", " ", Juul$Text)  # Remove the "RT" (retweet) so duplicates are duplicates
Juul$Text <- gsub("@\\w+", " ", Juul$Text)  # Remove user names (all proper names if you're wise!)
Juul$Text <- gsub("http.+ |http.+$", " ", Juul$Text)  # Remove links
Juul$Text <- gsub("[[:punct:]]", " ", Juul$Text)  # Remove punctuation
Juul$Text <- gsub("[ |\t]{2,}", " ", Juul$Text)  # Remove tabs
Juul$Text <- gsub("amp", " ", Juul$Text)  # "&" is "&amp" in HTML, so after punctuation removed ...
Juul$Text <- gsub("^ ", "", Juul$Text)  # Leading blanks
Juul$Text <- gsub(" $", "", Juul$Text)  # Lagging blanks
Juul$Text <- gsub(" +", " ", Juul$Text) # General spaces (should just do all whitespaces no?)

# Convert df to matrix for further analysis
Juul.matrix <- matrix(unlist(Juul),nrow = nrow(Juul))

# Then we can build the document-term matrix.
# build dtm
matrix <- create_matrix(Juul.matrix[,1], 
                        language = "english", 
                        removeStopwords = FALSE, 
                        removeNumbers = TRUE, 
                        stemWords = FALSE) 
# Sparsity = 100%
# The sparsity can help us decide whether we should use a linear kernel.

# Now, we can train the naive Bayes model with the training set. 
# Note that, e1071 asks the response variable to be numeric or factor. 
# Thus, we convert characters to factors here. This is a little trick.
# train the model
mat <- as.matrix(matrix)
classifier <- naiveBayes(mat[1:900, ], as.factor(Juul.matrix[1:900, 2]))

# Now we can step further to test the accuracy.
# test the validity
predicted <- predict(classifier, mat[901:1043, ])
predicted
table(Juul.matrix[901:1043, 2], predicted)
recall_accuracy(Juul.matrix[901:1043, 2], predicted)

# How about the other machine learning methods?
# As I mentioned, we can do it using RTextTools. Let's rock!
# First, to specify our data:
# build the data to specify response variable, training set, testing set.
# label_factor <- factor(Juul$Sentiment,
#                        ordered = TRUE,
#                        levels = c("Negative", 
#                                   "Neutral",
#                                   "Positive"))

# The 'container' in RTextTools is a type of object 
# that allows to operate all the functions with a common interface. 
# container <- create_container(matrix, 
#                               label_factor,
#                               trainSize = 1:900, 
#                               testSize = 901:1043, 
#                               virgin = FALSE)

container = create_container(matrix, 
                             as.numeric(as.factor(Juul[, 2])), 
                             trainSize = 1:900, 
                             testSize = 901:1043, 
                             virgin = FALSE)
# virgin = Specifies whether or not we have the correct answers.

# Algorithms to use, note that 'RF' and 'TREE' are a bit slower.
algorithms <- c("MAXENT", 
                "SVM", 
                "RF", 
                "BAGGING",
                "TREE")

# Second, to train the model with multiple machine learning algorithms:
models <- train_models(container, algorithms)

# Now, we can classify the testing set using the trained models.
results <- classify_models(container, models)
# How about the accuracy?
# accuracy table
table(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"FORESTS_LABEL"])
table(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"MAXENTROPY_LABEL"])

# recall accuracy
recall_accuracy(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"FORESTS_LABEL"])
# 68.5%
recall_accuracy(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"MAXENTROPY_LABEL"])
# 67.1%
recall_accuracy(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"TREE_LABEL"])
# 66.4%
recall_accuracy(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"BAGGING_LABEL"])
# 67.1%
recall_accuracy(as.numeric(as.factor(Juul.matrix[901:1043, 2])), results[,"SVM_LABEL"])
# 69.9%

# To summarize the results (especially the validity) in a formal way:
# model summary
analytics <- create_analytics(container, results)
summary(analytics)
head(analytics@document_summary)
analytics@ensemble_summary

# To cross validate the results (e.g. 10 folds validation):
# The purpose of CV is to find optimal parameters and 
# utimately improve model performance.  
N = 10
set.seed(2014)
cross_validate(container,N,"MAXENT")
# meanAccuracy = 95.4%
cross_validate(container,N,"TREE")
# meanAccuracy = 70.1%
cross_validate(container,N,"SVM")
# meanAccuracy = 72.7%
cross_validate(container,N,"RF")
# meanAccuracy = 72.9%

# Test tweets (unlabled)
# We don't have tags on the given test dataset (#Juul original tweets). 
# We will use our model to tag their entries and 
# then get a random sample of entries and manually inspect how are they tagged.

db <- dbConnect(drv=RSQLite::SQLite(), dbname='juul.db')
tables <- dbListTables(db)
Juul_Original <- dbReadTable(db, 'juul_unlabeled_table')
# This closes the connection, discards all pending work, and frees resources (e.g., memory, sockets).
dbDisconnect(db)
# 1,914 entries

# Data Preprocessing
Juul_Original$Text <- iconv(Juul_Original$Text, to = "ASCII", sub = " ")  # Convert to basic ASCII text to avoid silly characters
Juul_Original$Text <- tolower(Juul_Original$Text)  # Make everything consistently lower case
Juul_Original$Text <- gsub("rt", " ", Juul_Original$Text)  # Remove the "RT" (retweet) so duplicates are duplicates
Juul_Original$Text <- gsub("@\\w+", " ", Juul_Original$Text)  # Remove user names (all proper names if you're wise!)
Juul_Original$Text <- gsub("http.+ |http.+$", " ", Juul_Original$Text)  # Remove links
Juul_Original$Text <- gsub("[[:punct:]]", " ", Juul_Original$Text)  # Remove punctuation
Juul_Original$Text <- gsub("[ |\t]{2,}", " ", Juul_Original$Text)  # Remove tabs
Juul_Original$Text <- gsub("amp", " ", Juul_Original$Text)  # "&" is "&amp" in HTML, so after punctuation removed ...
Juul_Original$Text <- gsub("^ ", "", Juul_Original$Text)  # Leading blanks
Juul_Original$Text <- gsub(" $", "", Juul_Original$Text)  # Lagging blanks
Juul_Original$Text <- gsub(" +", " ", Juul_Original$Text) # General spaces (should just do all whitespaces no?)

# Merge training tweets and test tweets
# Juul.all <- rbind(Juul, Juul_Original)

Juul.all.matrix <- matrix(unlist(Juul_Original),nrow = nrow(Juul_Original))

matrix.all <- create_matrix(Juul.all.matrix[,1], 
                            originalMatrix = matrix,
                            language = "english", 
                            removeStopwords = FALSE, 
                            removeNumbers = TRUE, 
                            stemWords = FALSE) 

# originalMatrix = matrix ==> This is the previous test matrix that we created, 
# we NEED this parameter here, because essentially what we are training is on the words, 
# and we need to have the same words in the train, test and cross validation sets. 
# The originalMatrix parameter takes care of that.

trace("create_matrix",edit=T)
# In the source code box that pops up, 
# line 42 will have a misspelling of the word "acronym". 
# Change the "A" to an "a" and hit "Save".

# mat.all <- as.matrix(matrix.all)

# Build a NB classifier as a baseline
# classifier.all <- naiveBayes(mat, as.factor(Juul.matrix[,2]))


# predicted.all <- predict(classifier.all, mat.all[1:300,])
# predicted.all
# table(Juul.all.matrix[1:300, 2], predicted.all)

container.all <- create_container(matrix.all, 
                                  label_factor,
                                  trainSize = NULL, 
                                  testSize = 1:200, 
                                  virgin = FALSE)

# Second, to train the model with multiple machine learning algorithms:
# models.all <- train_models(container.all, algorithms)
# Now, we can classify the testing set using the trained models.
results.all <- classify_models(container.all, models)
table(as.numeric(as.factor(Juul.all.matrix[1:200, 2])), results.all[,"FORESTS_LABEL"])

library(dplyr)
svm.count <- results.all %>%
             filter(SVM_LABEL == "Negative") %>%
             count(SVM_LABEL)

library(ggplot2)
# Create a simple dataframe for predictions

# We will require at least two algorightms to agree on the class to be classified


# Change our predictions dataframe, if we have at least X algorithms agreeing on the results, then 
# we will keep the prediction, if not, we will set the prediction as "N/A"