## Juul Topic Modeling (LDA)
library(dplyr)
library(purrr)
library(NLP)
library(tm)
library(topicmodels)
library(SnowballC)
library(readr)
library(graphics)
library(RSQLite)
library(slam)
library(tidyverse)
library(tidytext)

db <- dbConnect(drv=RSQLite::SQLite(), dbname='juul.db')
tables <- dbListTables(db)
juul_merged <- dbReadTable(db, 'juul_merged_table')
# This closes the connection, discards all pending work, and frees resources (e.g., memory, sockets).
dbDisconnect(db)

df <- juul_merged

## 1. Text cleaing 
df$text <- iconv(tolower(df$text), "latin1", "ASCII", sub=" ")
df$text <- gsub("#.*? ", " ", df$text)
df$text <- gsub("#.*", " ", df$text)
df$text <- gsub("@.*? ", " ", df$text)
df$text <- gsub("@.*", " ", df$text)
df$text <- gsub("'", " ", df$text)
df$text <- gsub("http.*? ", " ", df$text)
df$text <- gsub("http.*", " ", df$text)
head(df$text)

nrow(df)

# compact language detector (cld)
cld2 <- cld2::detect_language(df$text)
index <- which(cld2 == 'en')
juul_merged <- juul_merged[index, ]
df <- df[index, ]

nrow(df)

## 2. Write a LDA function (as a template?)
# get & plot the most informative terms by a specificed number of topics
top_terms_by_topic_LDA <- function(input_text, # should be a columm from a dataframe
                                   plot = T, # return a plot? TRUE by defult
                                   number_of_topics = 4) # number of topics (4 by default)
{    
  # create a corpus (type of object expected by tm) and document term matrix
  Corpus <- Corpus(VectorSource(input_text)) # make a corpus object
  DTM <- DocumentTermMatrix(Corpus) # get the count of words/document
  
  # remove any empty rows in our document term matrix 
  # (if there are any we'll get an error when we try to run our LDA)
  unique_indexes <- unique(DTM$i) # get the index of each unique value
  DTM <- DTM[unique_indexes,] # get a subset of only those indexes
  
  # the tidy() method for tidying model objects. 
  # The tidytext package provides this method for extracting the per-topic-per-word probabilities, 
  # called β (“beta”), from the model.
  # preform LDA & get the words/topic in a tidy text format
  lda <- LDA(DTM, k = number_of_topics, control = list(seed = 1234))
  topics <- tidy(lda, matrix = "beta")
  
  topics
  # Notice that this has turned the model into a one-topic-per-term-per-row format. 
  # For each combination, the model computes the probability of that term being generated from that topic.
  # get the top ten terms for each topic
  
  top_terms <- topics  %>% # take the topics data frame and..
    group_by(topic) %>% # treat each topic as a different group
    top_n(10, beta) %>% # get the top 10 most informative words
    ungroup() %>% # ungroup
    arrange(topic, -beta) # arrange words in descending informativeness
  
  # if the user asks for a plot (TRUE by default)
  if(plot == T){
    # plot the top ten terms for each topic in order
    top_terms %>% # take the top terms
      mutate(term = reorder(term, beta)) %>% # sort terms by beta value 
      ggplot(aes(term, beta, fill = factor(topic))) + # plot beta by theme
      geom_col(show.legend = FALSE) + # as a bar plot
      facet_wrap(~ topic, scales = "free") + # which each topic in a seperate plot
      labs(x = NULL, y = "Beta") + # no x label, change y label 
      coord_flip() # turn bars sideways
  }else{ 
    # if the user does not request a plot
    # return a list of sorted terms instead
    return(top_terms)
  }
}

## 3. Create a document term matrix to clean
Corpus <- Corpus(VectorSource(df$text)) 

DTM <- DocumentTermMatrix(Corpus)

# convert the document term matrix to a tidytext corpus
DTM_tidy <- tidy(DTM)

# I'm going to add my own custom stop words that I don't think will be
# very informative in hotel reviews
custom_stop_words <- tibble(word = c("juul", "juuls", "juuling", "juuled", "i", "me", "my", "myself","we", "our", "ours", "ourselves", "you",
                                     "your", "yours", "amp"))

# remove stopwords
# DTM_tidy_cleaned <- DTM_tidy %>% # take our tidy dtm and...
#   anti_join(stop_words, by = c("term" = "word"))

DTM_tidy_cleaned <- DTM_tidy %>% # take our tidy dtm and...
  anti_join(stop_words, by = c("term" = "word")) %>% # remove English stopwords and...
  anti_join(custom_stop_words, by = c("term" = "word")) # remove my custom stopwords

# reconstruct cleaned documents (so that each word shows up the correct number of times)
cleaned_documents <- DTM_tidy_cleaned %>%
  group_by(document) %>% 
  mutate(terms = toString(rep(term, count))) %>%
  select(document, terms) %>%
  unique()

# check out what the cleaned documents look like (should just be a bunch of content words)
# in alphabetic order
head(cleaned_documents)

# stem vs lemmatization?
# stem the words (e.g. convert each word to its stem, where applicable)
# DTM_tidy_stemmed <- DTM_tidy_cleaned %>%
#   mutate(stem = wordStem(term))

# replace contraction
library(textclean)
DTM_tidy_cleaned <- DTM_tidy_cleaned %>%
  mutate(term = replace_contraction(term))

library(textstem)
library(hunspell)
lemma_dictionary_hs <- make_lemma_dictionary(DTM_tidy_cleaned$term, engine = 'hunspell')

DTM_tidy_stemmed <- DTM_tidy_cleaned %>%
  mutate(stem = lemmatize_words(term, 
                                dictionary = lemma_dictionary_hs))

custom_stop_words <- tibble(term = c("juul","juuls", "juuling", "juuled", "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you",
                                    "your", "yours", "amp"))

DTM_tidy_stemmed <- DTM_tidy_stemmed %>% # take our tidy dtm and...
  anti_join(custom_stop_words, by = "term")  # remove English stopwords and...

# reconstruct our documents
stemmed_documents <- DTM_tidy_stemmed %>%
  group_by(document) %>% 
  mutate(terms = toString(rep(stem, count))) %>%
  select(document, terms) %>%
  unique()

head(stemmed_documents)
nrow(stemmed_documents)

library(text2vec)
library(magrittr)

# define preprocessing function and tokenization function
prep_fun = tolower
tok_fun = word_tokenizer

it_train = itoken(stemmed_documents$terms, 
                  preprocessor = prep_fun, 
                  tokenizer = tok_fun, 
                  ids = stemmed_documents$document, 
                  progressbar = TRUE)

stop_words = c("i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours")
vocab = create_vocabulary(it_train, stopwords = stop_words)
pruned_vocab = prune_vocabulary(vocab, 
                                term_count_min = 10)
                                #                                  doc_proportion_max = 0.5,
                                #                                  doc_proportion_min = 0.001

head(pruned_vocab)
length(stemmed_documents$terms)
nrow(pruned_vocab)

JuulCorpus <- Corpus(VectorSource(stemmed_documents$terms)) # make a corpus object
JuulDTM <- DocumentTermMatrix(JuulCorpus) # get the count of words/document
rowTotals <- apply(JuulDTM , 1, sum) #Find the sum of words in each Document
# rowTotals
which(rowTotals ==0)
JuulDTM

length(JuulDTM$dimnames$Docs)

DTM_pruned <- JuulDTM[, slam::col_sums(JuulDTM > 0) >= 10]
DTM_pruned <- DTM_pruned[slam::row_sums(DTM_pruned > 0) > 0, ]

DTM_pruned
length(DTM_pruned$dimnames$Docs)

## 4. Fit the model
library(ldatuning)
result <- ldatuning::FindTopicsNumber(
  DTM_pruned,
  topics = seq(from = 2, to = 25, by = 1),
  metrics = c("Griffiths2004", "CaoJuan2009", "Arun2010", "Deveaud2014"),
  method = "Gibbs",
  control = list(seed = 77),
  mc.cores = 7L,
  verbose = TRUE
)

# library(ldatuning)
# result <- ldatuning::FindTopicsNumber(
#   DTM_pruned,
#   topics = seq(from = 2, to = 25, by = 1),
#   metrics = c("Griffiths2004", "CaoJuan2009", "Arun2010", "Deveaud2014"),
#   method = "Gibbs",
#   control = list(seed = 77),
#   mc.cores = 7L,
#   verbose = TRUE
# )

result
ldatuning::FindTopicsNumber_plot(result)

n_topics <- 13 # 7/13

# ap_lda <- LDA(DTM, k = 3, control = list(seed = 11091987))
ap_lda <- LDA(DTM_pruned, k = n_topics, control = list(seed = 11091987, alpha = 1/n_topics))
# ap_lda <- LDA(DTM_pruned, k = 3)
ap_lda_td <- tidy(ap_lda)

top_terms <- ap_lda_td %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

top_terms %>%
  mutate(term = reorder(term, beta)) %>%
  ggplot(aes(term, beta, fill = factor(topic))) +
  geom_bar(alpha = 0.8, stat = "identity", show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free", ncol = 3) +
  coord_flip()

# To see which documents belong to which topic with the highest probability in topic models, 
# simply use:
topics(ap_lda)

topicdocDF <- as.data.frame(topics(ap_lda))
library(data.table)
setDT(topicdocDF, keep.rownames = TRUE)[]
colnames(topicdocDF) <- c("document","topic")

topicdistr <- topicdocDF %>%
  count(topic, sort = TRUE) 

write.csv(topicdistr, "topicdistr.csv")

ggplot(topicdistr, aes(x=topic, y=n, fill=factor(topic)))+
   geom_bar(stat = "identity", color = "black")+
   theme_minimal()

ap_documents <- tidy(ap_lda, matrix = "gamma")

ap_documents <- ap_documents %>%
  group_by(document) %>%
  filter(gamma == max(gamma))

top_doc <- 13

# sample_docs <- data.frame()
# for (n_topic in 1:n_topics){
#   sorted <- ap_documents %>%
#     filter(topic == n_topic)  %>%
#     arrange(desc(gamma))
#   result <- data.frame(topic = n_topic, 
#                        tweet_id = as.character(juul_merged$tweet_id[as.numeric(stemmed_documents$document[as.numeric(unlist(sorted[1:top_doc,1] ))])]),
#                        tweet = juul_merged$text[as.numeric(stemmed_documents$document[as.numeric(unlist(sorted[1:top_doc,1] ))])])
#   sample_docs <- rbind(sample_docs, result)
# }
# sample_docs

sample_docs <- data.frame()
for (n_topic in 1:n_topics){
  sorted <- ap_documents %>%
    filter(topic == n_topic)  %>%
    arrange(desc(gamma))
  result <- data.frame(topic = n_topic,
                       tweet_id = as.character(juul_merged$tweet_id[as.numeric(stemmed_documents$document[as.numeric(unlist(sorted[ , 1] ))])])
  )
  sample_docs <- rbind(sample_docs, result)
}
sample_docs
sample_docs <- distinct(sample_docs, tweet_id, .keep_all = TRUE)
sample_docs
library(csvread)
sample_docs$tweet_id <- as.character(sample_docs$tweet_id)
sample_docs$tweet_id <- as.integer64.character(sample_docs$tweet_id)

juul_ts <- juul_merged %>%
  select(tweet_id, tweet_created_at_date)

juul_ts <- inner_join(juul_ts, sample_docs)

juul_ts$tweet_created_at_date <- substr(juul_ts$tweet_created_at_date, 1, 10)
juul_ts$tweet_created_at_date <- as.Date(juul_ts$tweet_created_at_date)

juul_ts <- juul_ts %>%
  select(tweet_created_at_date, topic) %>%
  filter(topic %in% c("2", "5", "13")) # %>%
  # group_by(topic) %>%
  # count(topic)

library(xts)
library(zoo)

school_ts <- juul_ts %>%
  group_by(tweet_created_at_date) %>%
  filter(topic == "2") %>%
  count(topic) %>%
  mutate(topic=replace(topic, topic==2, "School"))
  
addiction_ts <- juul_ts %>%
  group_by(tweet_created_at_date) %>%
  filter(topic == "5") %>%
  count(topic) %>%
  mutate(topic=replace(topic, topic==5, "Addiction"))

cessation_ts <- juul_ts %>%
  group_by(tweet_created_at_date) %>%
  filter(topic == "13") %>%
  count(topic) %>%
  mutate(topic=replace(topic, topic==13, "Cessation"))

library(readr)
write.csv(school_ts, file = "school_ts.csv")
write.csv(addiction_ts, file = "addiction_ts.csv")
write.csv(cessation_ts, file = "cessation_ts.csv")

length(unique(sample_docs$tweet_id))
#df[a[1:3,1], ]
write.csv(file="topics", x = sample_docs, row.names=FALSE)

pruned_vocab <- pruned_vocab[order(-pruned_vocab[, 3]),]
pruned_vocab['%'] <- format(round(100 * pruned_vocab$doc_count/nrow(df), 2), nsmall = 2)
rownames(pruned_vocab) <- NULL
pruned_vocab[1:10,c('term', '%')]
