# Let’s use the lubridate package to convert the string timestamps to date-time objects 
# and initially take a look at our tweeting patterns overall. 
library(lubridate)
library(ggplot2)
library(dplyr)
library(readr)
library(RSQLite)

db <- dbConnect(drv=RSQLite::SQLite(), dbname='juul.db')
tables <- dbListTables(db)
juul_merged <- dbReadTable(db, 'juul_merged_table')
# This closes the connection, discards all pending work, and frees resources (e.g., memory, sockets).
dbDisconnect(db)

## 1. Basic Stats
str(juul_merged)
dim(juul_merged)
# unique users 
length(unique(juul_merged$user_id))
n_distinct(juul_merged$user_id)
# verified users
sum(juul_merged$verified == 1)
# time span
min(juul_merged$tweet_created_at_date)
max(juul_merged$tweet_created_at_date)

## Getting the distribution of tweets
# tweets <- juul_merged %>%
#  mutate(timestamp = ymd_hms(tweet_created_at_date))

# ggplot(tweets, aes(x = timestamp, fill = "red")) +
#   geom_histogram(position = "identity", bins = 20, show.legend = FALSE)

## 2. Geo-location Analysis
# 2.1 Location Distribution
# Let’s learn a bit more about these people tweeting about juul. First, where are they from?
# how many locations are represented
length(unique(juul_merged$location))

# Let’s sort by count and just plot the top locations. To do this you use top_n(). 
# Note that in this case you are grouping your data by user. 
# Thus top_n() will return locations with atleast 15 users associated with it.
juul_merged %>%
  count(location, sort = TRUE) %>%
  mutate(location = reorder(location, n)) %>%
  na.omit() %>%
  top_n(20) %>%
  ggplot(aes(x = location, y = n)) +
  geom_col() +
  coord_flip() +
  labs(x = "Count",
       y = "Location",
       title = "Where Twitter users are from - unique locations ")

# 2.2 Coordinates
library(dplyr)
juul_geo <- juul_merged %>%
  select(user_id, screen_name, text, tweet_created_at_date, location, coordinates) %>%
  distinct(user_id, .keep_all = TRUE) %>%
  filter(!(coordinates == 'null'))

# load twitter library - the rtweet library is recommended now over twitteR
library(rjson)
library(jsonlite)
# plotting and pipes - tidyverse!
library(ggplot2)
library(tidyr)

# animated maps
# to install: devtools::install_github("dgrtwo/gganimate")
# note this required imagemagick to be installed
library(leaflet)
# library(gganimate)
library(maps)
library(ggthemes)

options(stringsAsFactors = FALSE)

juul_geo <- juul_geo %>%
  mutate(coordinates = gsub("\\)|c\\(", "", coordinates)) %>%
  separate(coordinates, c("long", "lat"), sep = ", ") %>%
  mutate_at(c("lat", "long"), as.numeric)

# create basemap of the globe
world_basemap <- ggplot() +
  borders("world", colour = "gray85", fill = "gray80")

world_basemap

world_basemap +
  geom_point(data = juul_geo, aes(x = long, y = lat),
             colour = 'purple', alpha = .5) +
  scale_size_continuous(range = c(1, 8),
                        breaks = c(250, 500, 750, 1000)) +
  labs(title = "Juul Tweet Geo-location")

# plot points on top of a leaflet basemap

site_locations <- leaflet(juul_geo) %>%
  addTiles() %>%
  addCircleMarkers(lng = ~long, lat = ~lat, radius = 3, stroke = FALSE)

site_locations

# plot points on top of a leaflet basemap

site_locations_base <- leaflet(juul_geo) %>%
  addProviderTiles("CartoDB.Positron") %>%
  addCircleMarkers(lng = ~long, lat = ~lat, radius = 3, stroke = FALSE)

site_locations_base



