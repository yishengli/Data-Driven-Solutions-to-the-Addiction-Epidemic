setwd("C:/Projects/r_Studio/SYST538_Financial_Engineering")

library(ggplot2)

# Import the dataset
my_data = read.csv('Data_DAEN/Final_Dataset.csv', stringsAsFactors = F, header = T)
head(my_data)
names(my_data)

#Exploratory Data Analysis

#plot(my_data$Average_Overdoses_2_years ~ my_data$Unemployment_Rat_17)

ggplot(my_data, aes (x = Drug_deaths_16)) + geom_histogram(binwidth = 5) +
    labs(x = "Opioid Deaths 2016", y = "Number of Counties", title = "Opioids Drug Deaths Histogram") +
    theme(text = element_text(size=20))


pairs(my_data[,3:9], cex.labels = 1.5, cex = 1.5, main = "Pair Plots")



# Modelling

model1 = glm(Drug_deaths_16 ~ ER_Visits_16 + EMS_Narcan_16 + ER_Visits_15 + Drug_deaths_15 + EMS.Narcan_15 + Unemployment_Rate +
                 Opioid_Prescription_Rate + Bup_Providers, data = my_data, family = poisson)

summary (model1)


CI <- exp(confint.default(model1))

#Goodness of fit test If the residual deviance is close enough to the residual degrees of freedom,(link = log)
#it is a good fit. It can be tested by Chi-squared test.

list(residual.deviance           = deviance(model1),
     residual.degrees.of.freedom = df.residual(model1),
     chisq.p.value               = pchisq(deviance(model1), df.residual(model1), lower = F)
)

qchisq(0.95, df.residual(model1))


ggplot(data = my_data, aes(Drug_deaths_16 , y = predict(model1, type = "response"))) +
    geom_point() + xlab("Math score") + ylab("Expected number of awards")


length(my_data$Drug_deaths_16)

# model2 = glm(Drug_deaths_16 ~ ER_Visits_16 + EMS_Narcan_16 + Unemployment_Rate + Drug_deaths_15 + + ER_Visits_15 + Opioid_Prescription_Rate,
#              data = my_data, family = poisson(link = log))
# summary (model2)
# 1.000 - pchisq(summary(model1)$deviance,summary(model1)$df.residual)
# plot(model1)
# anova(model3)

# Export of the data


myoutput = data.frame(my_data$Drug_deaths_16, pred = model1$fitted)

myoutput$percentage = round(((model3$fitted/ my_data$Population_16) *10000),4)

myoutput


write.csv(myoutput, file = "myoutput.csv",row.names=FALSE)

quantile(myoutput$percentage)

plot(myoutput$Average_Fatalities_2_years)
points(myoutput$pred, pch = "p", col = "red")
